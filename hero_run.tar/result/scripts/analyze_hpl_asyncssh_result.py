import sys
import json
from parse_hpl_result import parse_hpl_result
import numpy

def analyze_hpl_result(data):
    result = []
    for d in data:
        idx = d['id']
        code = d['code']
        stdout = d['stdout']
        stderr = d['stderr']
        if code == 0:
            result.append({'id': idx, 'gflops': parse_hpl_result(stdout)})
        else:
            result.append({'id': idx, 'gflops': 0})
    return result
if __name__ == '__main__':
    lines = sys.stdin.readlines()
    s = ''.join(lines)
    data = json.loads(s)
    result = analyze_hpl_result(data)
    # result = list(filter(lambda x: x['id'] <= 300, result))

    result.sort(key=lambda x: x['gflops'], reverse=True)
    print(len(result))

    # print(result)

    gflops = [e['gflops'] for e in result]
    mean = numpy.mean(gflops)
    std = numpy.std(gflops)
    max_gflops = max(gflops)
    min_gflops = min(gflops)
    print('mean: {}, std: {}, max: {}, min: {}'.format(mean, std, max_gflops, min_gflops))