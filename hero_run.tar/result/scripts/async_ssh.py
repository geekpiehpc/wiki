#!/usr/bin/python3
import asyncio, asyncssh, sys
import sys
import json
from typing import List, Tuple

SSH_FAILED_MAGIC = 114514

async def run_client(id: int, command: str) -> Tuple[int, str, str]:
    host = 'node-{}'.format(id)
    try:
        async with asyncssh.connect(host, known_hosts=None) as conn:
            print('Connected to {}'.format(host))
            result = await conn.run(command, check=True)
            print('Disconneted from {}'.format(host))
            return result.returncode, result.stdout, result.stderr
    except (OSError, asyncssh.Error) as exc:
        print('Connection failed: {}'.format(exc), file=sys.stderr)
        return SSH_FAILED_MAGIC, '', ''


async def run_clients(nodes: List[int], command: str = 'hostname'):
    tasks = []
    for i in nodes:
        tasks.append(run_client(i, command))
    return await asyncio.gather(*tasks)

if __name__ == '__main__':
    if len(sys.argv) != 4:
        print('Usage: {} <start> <end> <command>'.format(sys.argv[0]))
        print('Example: {} 1 10 "hostname"'.format(sys.argv[0]))
        print(' This will run "hostname" on node-1 to node-10')
        exit(1)
    node_ids = list(range(int(sys.argv[1]), int(sys.argv[2]) + 1))
    command = sys.argv[3]
    
    results = asyncio.get_event_loop().run_until_complete(run_clients(node_ids, command))
    ssh_failed_idx = [i for i, r in enumerate(results) if r[0] == SSH_FAILED_MAGIC]
    success_idx = [i for i, r in enumerate(results) if r[0] == 0]
    failed_idx = [i for i, r in enumerate(results) if r[0] != 0 and r[0] != SSH_FAILED_MAGIC]

    for idx in range(len(results)):
        host = 'node-{}:'.format(node_ids[idx])
        if results[idx][0] == SSH_FAILED_MAGIC:
            print(host, 'SSH failed')
        else:
            code = results[idx][0]
            out = results[idx][1].strip()
            err = results[idx][2].strip()

            msg = host
            if code != 0:
                msg += ' Failed with code {} '.format(code)
            if out:
                msg += ' stdout: {}'.format(out)
            if err:
                msg += ' stderr: {}'.format(err)
            print(msg)

    print('SSH failed count: {}'.format(len(ssh_failed_idx)))
    print('Success count: {}'.format(len(success_idx)))
    print('Failed count: {}'.format(len(failed_idx)))

    print('SSH failed nodes: {}'.format([node_ids[i] for i in ssh_failed_idx]))
    print('Success nodes: {}'.format([node_ids[i] for i in success_idx]))
    print('Failed nodes: {}'.format([node_ids[i] for i in failed_idx]))

    json_data = [{'id': node_ids[i], 'code': results[i][0], 'stdout': results[i][1], 'stderr': results[i][2]} for i in range(len(results))]
    json_str = json.dumps(json_data)
    # get current time
    import time
    t = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime())
    json_file_name = 'result-{}.json'.format(t)
    with open(json_file_name, 'w') as f:
        f.write(json_str)
    print('Result saved to {}'.format(json_file_name))