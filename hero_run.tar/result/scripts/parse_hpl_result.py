import queue
import sys
import os

def parse_hpl_result(s: str) -> float:
    if 'FAIL' in s:
        return 0
    arr = s.split('\n')
    table_begin = 'T/V                N    NB     P     Q               Time                 Gflops'
    table_idxs = [i for i, x in enumerate(arr) if x == table_begin]

    results = [arr[i+2] for i in table_idxs]

    gflops = [float(e.split(' ')[-1]) for e in results]
    
    max_gflops = max(gflops)
    return max_gflops

if __name__ == '__main__':
    lines = sys.stdin.readlines()
    s = ''.join(lines)
    print(parse_hpl_result(s))