#!/bin/bash
echo "" > "host$1"
for i in `seq $1`; do
  echo "node-$i slots=20" >> "host$1"
done
