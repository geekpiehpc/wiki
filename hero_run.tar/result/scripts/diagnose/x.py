import subprocess
import re
from datetime import time, date, datetime

r_start = r'HPL_pdgesv\(\) start time\s+Tue Oct 25 (\d{2}):(\d{2}):(\d{2})'
r_end = r'HPL_pdgesv\(\) end time\s+Tue Oct 25 (\d{2}):(\d{2}):(\d{2})'

def parse_output(i):
    start = None
    end = None
    for j in i.stdout:
        current = j.decode('ascii')
        if re.search(r_start,current):
            match = re.search(r_start,current)
            start = time(int(match[1]), int(match[2]), int(match[3]))
        if re.search(r_end, current):
            match = re.search(r_end,current)
            end = time(int(match[1]), int(match[2]), int(match[3]))
    if start and end:
        return (datetime.combine(date.today(), end) - datetime.combine(date.today(), start)).seconds
    return None

if __name__=="__main__":
    p=[]
    duration = []
    for k in range(37):
        print("{}".format(k))
        p.append( subprocess.Popen(["/share/hero_mkl_seq_diagnose/run.sh","{}".format(k)], stdout=subprocess.PIPE, stderr=subprocess.PIPE))
    for idx, i in enumerate(p):
        i.wait()
        result = parse_output(i)
        if not result:
            print("{} failed.".format(idx))
        else:
            duration.append((idx,result))
    duration = sorted(duration, key=lambda x: x[1])
    list(map(lambda x: print("{} costs {}".format(x[0],x[1])),duration))