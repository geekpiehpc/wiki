if __name__=="__main__":
    a=list(range(215))+list(range(216,301))
    print(a)
    for i in range(37):
        with open('host_range__{}'.format(i),'w') as f:
            for j in range(8):
                f.write('node-{} slots=20\n'.format(a[i*8+j+1]))