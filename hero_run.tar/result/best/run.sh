#!/bin/sh
source /share/spack/share/spack/setup-env.sh
spack load openmpi/237l
spack load hpl/ud5
cd /share/hero_mkl_sequential
/share/spack/opt/spack/linux-centos8-haswell/gcc-12.2.0/openmpi-4.1.4-237ltryogtpjqstl2lwa7l36wp3lt3fv/bin/mpirun --hostfile host_final -np 6000 --map-by core /share/hero_mkl_sequential/node-hpl.sh