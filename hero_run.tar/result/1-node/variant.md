
# Open MPI and HPL

```
237ltryogtpjqstl2lwa7l36wp3lt3fv openmpi@4.1.4~atomics~cuda~cxx~cxx_exceptions~gpfs~internal-hwloc~java~legacylaunchers~lustre~memchecker+romio+rsh~singularity+static+vt+wrapper-rpath fabrics=ucx schedulers=none
```

```
-- linux-centos8-haswell / gcc@12.2.0 ---------------------------
xxxa4ak3t6o423pouncjftufwaiojnxi hpl@2.3~openmp
fsmavjtmletl42svb5ncvbpbnc665rum     intel-oneapi-mkl-sequential@2022.2.0~cluster~ilp64+shared
ty2pqxed2pdith63fjnphn73blpl25f2         intel-oneapi-tbb@2021.7.0
b4bv2tdtsrqbffsmcyliqu62jvvuxexi     intel-oneapi-mpi@2021.7.0~external-libfabric~generic-names~ilp64
```

# Spack HPL diff:

```
diff --git a/var/spack/repos/builtin/packages/hpl/package.py b/var/spack/repos/builtin/packages/hpl/package.py
index cd1d446e80..9fd4e1a68d 100644
--- a/var/spack/repos/builtin/packages/hpl/package.py
+++ b/var/spack/repos/builtin/packages/hpl/package.py
@@ -106,7 +106,7 @@ def configure_args(self):
         if "+openmp" in self.spec:
             config = ["CFLAGS=-O3 " + self.compiler.openmp_flag]
         else:
-            config = ["CFLAGS=-O3"]
+            config = ["CFLAGS=-O3 -fomit-frame-pointer -fprofile-use=/share/hpl_profile"]
 
         if (
             self.spec.satisfies("^intel-mkl")
```


# intel-oneapi-mkl-sequential package.py:

```python
# Copyright 2013-2022 Lawrence Livermore National Security, LLC and other
# Spack Project Developers. See the top-level COPYRIGHT file for details.
#
# SPDX-License-Identifier: (Apache-2.0 OR MIT)


import platform

from spack.package import *


@IntelOneApiPackage.update_description
class IntelOneapiMklSequential(IntelOneApiLibraryPackage):
    """Intel oneAPI Math Kernel Library (Intel oneMKL; formerly Intel Math
    Kernel Library or Intel MKL), is a library of optimized math
    routines for science, engineering, and financial
    applications. Core math functions include BLAS, LAPACK,
    ScaLAPACK, sparse solvers, fast Fourier transforms, and vector
    math.

    """

    maintainers = ["rscohn2"]

    homepage = (
        "https://software.intel.com/content/www/us/en/develop/tools/oneapi/components/onemkl.html"
    )

    if platform.system() == "Linux":
        version(
            "2022.2.0",
            url="https://registrationcenter-download.intel.com/akdlm/irc_nas/18898/l_onemkl_p_2022.2.0.8748_offline.sh",
            sha256="07d7caedd4b9f025c6fd439a0d2c2f279b18ecbbb63cadb864f6c63c1ed942db",
            expand=False,
        )
        version(
            "2022.1.0",
            url="https://registrationcenter-download.intel.com/akdlm/irc_nas/18721/l_onemkl_p_2022.1.0.223_offline.sh",
            sha256="4b325a3c4c56e52f4ce6c8fbb55d7684adc16425000afc860464c0f29ea4563e",
            expand=False,
        )
        version(
            "2022.0.2",
            url="https://registrationcenter-download.intel.com/akdlm/irc_nas/18483/l_onemkl_p_2022.0.2.136_offline.sh",
            sha256="134b748825a474acc862bb4a7fada99741a15b7627cfaa6ba0fb05ec0b902b5e",
            expand=False,
        )
        version(
            "2022.0.1",
            url="https://registrationcenter-download.intel.com/akdlm/irc_nas/18444/l_onemkl_p_2022.0.1.117_offline.sh",
            sha256="22afafbe2f3762eca052ac21ec40b845ff2f3646077295c88c2f37f80a0cc160",
            expand=False,
        )
        version(
            "2021.4.0",
            url="https://registrationcenter-download.intel.com/akdlm/irc_nas/18222/l_onemkl_p_2021.4.0.640_offline.sh",
            sha256="9ad546f05a421b4f439e8557fd0f2d83d5e299b0d9bd84bdd86be6feba0c3915",
            expand=False,
        )
        version(
            "2021.3.0",
            url="https://registrationcenter-download.intel.com/akdlm/irc_nas/17901/l_onemkl_p_2021.3.0.520_offline.sh",
            sha256="a06e1cdbfd8becc63440b473b153659885f25a6e3c4dcb2907ad9cd0c3ad59ce",
            expand=False,
        )
        version(
            "2021.2.0",
            url="https://registrationcenter-download.intel.com/akdlm/irc_nas/17757/l_onemkl_p_2021.2.0.296_offline.sh",
            sha256="816e9df26ff331d6c0751b86ed5f7d243f9f172e76f14e83b32bf4d1d619dbae",
            expand=False,
        )
        version(
            "2021.1.1",
            url="https://registrationcenter-download.intel.com/akdlm/irc_nas/17402/l_onemkl_p_2021.1.1.52_offline.sh",
            sha256="818b6bd9a6c116f4578cda3151da0612ec9c3ce8b2c8a64730d625ce5b13cc0c",
            expand=False,
        )

    variant("shared", default=True, description="Builds shared library")
    variant("ilp64", default=False, description="Build with ILP64 support")
    variant(
        "cluster", default=False, description="Build with cluster support: scalapack, blacs, etc"
    )

    depends_on("intel-oneapi-tbb")
    # cluster libraries need mpi
    depends_on("mpi", when="+cluster")

    provides("fftw-api@3")
    provides("scalapack", when="+cluster")
    provides("mkl")
    provides("lapack")
    provides("blas")

    @property
    def component_dir(self):
        return "mkl"

    @property
    def headers(self):
        return find_headers("*", self.component_prefix.include)

    @property
    def libs(self):
        shared = "+shared" in self.spec

        libs = self._find_mkl_libs(shared)

        system_libs = find_system_libraries(["libpthread", "libm", "libdl"])
        if shared:
            return libs + system_libs
        else:
            return IntelOneApiStaticLibraryList(libs, system_libs)

    def setup_run_environment(self, env):
        super(IntelOneapiMklSequential, self).setup_run_environment(env)

        # Support RPATH injection to the library directories when the '-mkl' or '-qmkl'
        # flag of the Intel compilers are used outside the Spack build environment. We
        # should not try to take care of other compilers because the users have to
        # provide the linker flags anyway and are expected to take care of the RPATHs
        # flags too. We prefer the __INTEL_POST_CFLAGS/__INTEL_POST_FFLAGS flags over
        # the PRE ones so that any other RPATHs provided by the users on the command
        # line come before and take precedence over the ones we inject here.
        for d in self._find_mkl_libs("+shared" in self.spec).directories:
            flag = "-Wl,-rpath,{0}".format(d)
            env.append_path("__INTEL_POST_CFLAGS", flag, separator=" ")
            env.append_path("__INTEL_POST_FFLAGS", flag, separator=" ")

    def setup_dependent_build_environment(self, env, dependent_spec):
        env.set("MKLROOT", self.component_prefix)

    def _find_mkl_libs(self, shared):
        libs = []

        if "+cluster" in self.spec:
            libs.extend([self._xlp64_lib("libmkl_scalapack"), "libmkl_cdft_core"])

        libs.extend([self._xlp64_lib("libmkl_intel"), "libmkl_sequential", "libmkl_core"])

        if "+cluster" in self.spec:
            libs.append(self._xlp64_lib("libmkl_blacs_intelmpi"))

        return find_libraries(libs, self.component_prefix.lib.intel64, shared=shared)

    def _xlp64_lib(self, lib):
        return lib + ("_ilp64" if "+ilp64" in self.spec else "_lp64")
```