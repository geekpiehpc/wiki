#!/bin/sh
source /share/spack/share/spack/setup-env.sh
spack load intel-oneapi-mpi/b4bv
spack load hpl/xxxa
cd /share/hero_mkl_sequential_intel_mpi
/share/spack/opt/spack/linux-centos8-haswell/intel-2021.7.0/intel-oneapi-mpi-2021.7.0-b4bv2tdtsrqbffsmcyliqu62jvvuxexi/mpi/latest/bin/mpirun -np 20 --map-by core xhpl